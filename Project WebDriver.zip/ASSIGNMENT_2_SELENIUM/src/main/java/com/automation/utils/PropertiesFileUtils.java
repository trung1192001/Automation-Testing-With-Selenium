package com.automation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;


public class PropertiesFileUtils {
	public static String CONFIG_PATH ="./configuration/configs.properties";
	
	public static String getProperty(String key) {
		Properties properties = new Properties();
		File filepath = new File(CONFIG_PATH);
		FileInputStream fileInputStream = null;
		String result = null;
		try {
			fileInputStream = new FileInputStream(filepath);
			properties.load(fileInputStream);
			result = properties.getProperty(key);
			return result;
		}
		catch (Exception e) {
			System.out.println("Xảy ra lỗi khi lấy giá trị từ file properties");
			e.printStackTrace();
		}
		finally {
			if(fileInputStream != null) {
				try {
					fileInputStream.close();
				}
				catch (Exception e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}
		return result;
	}
}

