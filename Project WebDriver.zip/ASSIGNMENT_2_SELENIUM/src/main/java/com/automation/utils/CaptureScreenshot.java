package com.automation.utils;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;

import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;


public class CaptureScreenshot {
	
	public static void takeScreenshot(WebDriver driver, String name) throws HeadlessException, AWTException, IOException {
		String filePath = null;
		try {
			
			//Tạo file chứa ảnh
			File filescreenshot = new File("./screenshots");
			
			//Kiểm tra tồn tại của file
			if(!filescreenshot.exists()) {
				filescreenshot.mkdirs();
			}
			
			BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			Calendar calendar = Calendar.getInstance();
			
			filePath = "./screenshots/" + name + calendar.getTime().toString().replace(":", "").replace(" ", "") +".jpg";
			File eviImage = new File(filePath);
			ImageIO.write(image, "jpg", eviImage);
		}
		catch (Exception e) {
			System.out.println("Xảy ra lỗi trong khi chụp màn hình");
			e.printStackTrace();
		}
		
		attachScreenShot(filePath);
	}
	
	
	public static void attachScreenShot(String filename) {
	    try {
	    	System.setProperty("org.uncommons.reportng.escape-output", "false");
	        // Escape HTML characters in the file path
	        File file = new File(filename);

	        // Đính kèm hình ảnh vào báo cáo TestNG sử dụng Reporter.log
	        Reporter.log("<br><a title=\"Screenshot\" href=\"" + file.getAbsolutePath() + "\" >"
	                + "<img alt= \"" + file.getName() +"\"src=\"file://" + file.getAbsolutePath() + "\" height='243' width='418'> </a><br>");

	    } catch (Exception e) {
	        System.out.println("Xảy ra lỗi trong khi đính kèm ảnh vào báo cáo");
	        e.printStackTrace();
	    }
	}
}

