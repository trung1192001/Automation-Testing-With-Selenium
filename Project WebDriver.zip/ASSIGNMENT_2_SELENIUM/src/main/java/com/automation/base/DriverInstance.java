package com.automation.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverInstance {
	protected WebDriver driver;
	
	@BeforeClass
	public void initDriverInstance() {
		
		//khởi tạo chrome driver
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		//Mở cửa sổ trình duyệt full kích thước
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}
	
	@AfterClass
	public void closeDriverInstance() {
		driver.close();
	}
}
