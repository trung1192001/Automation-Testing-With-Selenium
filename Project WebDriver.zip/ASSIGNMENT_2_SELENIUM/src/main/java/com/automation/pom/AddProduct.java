package com.automation.pom;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.automation.utils.CaptureScreenshot;

public class AddProduct {
	private WebDriverWait wait, wait2;
	public WebDriver driver;
	public Actions action;
	
	public AddProduct(WebDriver driver) {
		wait = new WebDriverWait(driver, 30);
		wait2 = new WebDriverWait(driver, 5);
		action = new Actions(driver);
	}
	
	public void Click_ProductButton() throws HeadlessException, AWTException, IOException {
		try {
			WebElement productButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href=\"/products\"]")));
			action.click(productButton).build().perform();
		}
		catch (Exception e) {
			System.out.println("Xảy ra lỗi khi truy cập vào mục 'Products'");
			CaptureScreenshot.takeScreenshot(driver, "AccessProductsError_");
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	public void Search_Product(String nameProduct) throws HeadlessException, AWTException, IOException {
		try {
			
			//nhập keyword vào ô tìm kiếm và sau đó click chuột vào biểu tượng tìm kiếm
			WebElement inputSearch = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("search_product")));
			WebElement searchButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("submit_search"))); //xác định ví trí biểu tượng tìm kiếm
			action.sendKeys(inputSearch, nameProduct).click(searchButton).build().perform();
			
			//cài đặt thời gian tìm kiếm tối đa 5s và Kiểm tra quá trình tìm kiếm 
			WebElement resultSearch = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text() ='Searched Products']")));
			
			action.sendKeys(Keys.PAGE_DOWN).build().perform();
	
			
			
			//Kiểm tra hình ảnh hiển thị Item
			WebElement imageLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@src='/get_product_picture/4']")));
			
			//Kiểm tra item được hiển thị cùng tên tìm kiếm 
			WebElement productName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='productinfo text-center']/p")));
			if(productName.isDisplayed()) {
				Assert.assertEquals(productName.getText(), nameProduct);
			}
			
			//Kiểm tra item được hiển thị chứa thông tin giá bán
			WebElement CostItem = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='productinfo text-center']/h2")));
			Assert.assertTrue(CostItem.getText().length() > 0);
			
			//Đảm bảo button “Add to cart” được hiển thị trên Item
			WebElement btnAddToCart = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Add to cart']")));
		} 
		catch (Exception e) {
				System.out.println("Xảy ra lỗi khi tìm kiếm sản phẩm");
				CaptureScreenshot.takeScreenshot(driver, "SearchProductError_");
				e.printStackTrace();
				Assert.fail();
		}
	}
	
	public void Add_Product() throws HeadlessException, AWTException, IOException {
		try {
			
			WebElement btnAddToCart = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Add to cart']")));
			Assert.assertTrue(btnAddToCart.isDisplayed());
			
			//Thực hiện click vào button “Add to card”
			action.click(btnAddToCart).build().perform();
			
			//đảm bảo addResponseMsg đã được hiển thị trên websites
			WebElement addResponseMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Your product has been added to cart.']")));
			
			//Đảm bảo việc thêm mới thành công với việc hiển thị thông báo.
			Assert.assertEquals(addResponseMsg.getText(), "Your product has been added to cart.");
			
			//Đóng thông báo
			WebElement button_close = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Continue Shopping']")));
			action.click(button_close).build().perform();
		}
		catch (Exception e) {
			System.out.println("Xảy ra lỗi khi thêm sản phẩm");
			CaptureScreenshot.takeScreenshot(driver, "CloseNotificationError_");
			e.printStackTrace();
			Assert.fail();
		}
		
		
	}
}
