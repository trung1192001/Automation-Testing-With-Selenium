package com.automation.pom;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.automation.utils.CaptureScreenshot;
import com.automation.utils.PropertiesFileUtils;

public class LoginPage {
	private WebDriverWait wait;
	public WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		wait = new WebDriverWait(driver, 30);
	}

	
	//Click vào icon Signup/Login
	public void click_SignIn() throws HeadlessException, AWTException, IOException {
		try {
			String XPicon_SignIn = PropertiesFileUtils.getProperty("icon_signin");
			WebElement iconSignin = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPicon_SignIn)));
			iconSignin.click();
		}
		catch (Exception e) {
			
			System.out.println("Xảy ra lỗi khi click icon Sign In");
			CaptureScreenshot.takeScreenshot(driver, "clickSigInError_");
			e.printStackTrace();
			Assert.fail();
		}
			
	}
		
	//Nhập email
	public void enterEmail(String email) throws HeadlessException, AWTException, IOException {
		try {
			String XPemail = PropertiesFileUtils.getProperty("login_email");
			WebElement inputEmail = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPemail)));
			inputEmail.sendKeys(email);
			
		}
		catch (Exception e) {
			
			System.out.println("Xảy ra lỗi khi nhập thông tin Email");
			CaptureScreenshot.takeScreenshot(driver, "enterEmailError_");
			e.printStackTrace();
			Assert.fail();
		}	
	}
	
	//Nhập passowrd
	public void enterPassword(String password) throws HeadlessException, AWTException, IOException {
		try {
			String XPpassword = PropertiesFileUtils.getProperty("login_password");
			WebElement inputPassword = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPpassword)));
			inputPassword.sendKeys(password);
		
		}
		catch (Exception e) {
			
			System.out.println("Xảy ra lỗi khi nhập thông tin Password");
			CaptureScreenshot.takeScreenshot(driver, "enterPasswordError_" );
			e.printStackTrace();
			Assert.fail();
		}
		
	}
	
	//Click vào nút Login
	public void clickLogIn_SignIn() throws HeadlessException, AWTException, IOException {
		try {
			String XPLogin_signin = PropertiesFileUtils.getProperty("login_signin");
			WebElement Login_signin = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPLogin_signin)));
			Login_signin.click();
	
			String XPicon_signout = PropertiesFileUtils.getProperty("icon_signout");
			WebElement iconSignOut = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPicon_signout)));
			
		} catch (Exception e) {
			
			System.out.println("Xảy ra lỗi khi thực hiện đăng nhập");
			CaptureScreenshot.takeScreenshot(driver, "clickLogindError_" );
			e.printStackTrace();
			Assert.fail();
		}
			
	}
	
	public void click_SignOut() throws HeadlessException, AWTException, IOException {
		try {
			String XPicon_signout = PropertiesFileUtils.getProperty("icon_signout");
			WebElement iconSignOut = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPicon_signout)));
			iconSignOut.click();
		}
		catch (Exception e) {
			
			System.out.println("Xảy ra lỗi khi đăng xuất");
			CaptureScreenshot.takeScreenshot(driver, "clickLogoutdError_" );
			e.printStackTrace();
			Assert.fail();
			
		}
	}
}
