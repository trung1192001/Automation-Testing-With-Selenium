package com.automation.testcase;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.automation.base.DriverInstance;
import com.automation.pom.LoginPage;
import com.automation.utils.PropertiesFileUtils;

public class TC_LoginTest extends DriverInstance {
	
	@Test(dataProvider = "Excel")
	public void TC01_LoginFirstAccount(String email, String password) throws HeadlessException, AWTException, IOException, InterruptedException  {
		//Hướng đến trang web
		String URL = PropertiesFileUtils.getProperty("base_url");
		driver.navigate().to(URL);
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		//Lấy định danh iconSignin từ properties file và tìm kiếm, click
		String XPicon_signin = PropertiesFileUtils.getProperty("icon_signin");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPicon_signin)));
		
		LoginPage loginPage = new LoginPage(driver);
		PageFactory.initElements(driver, loginPage);
			
		//Thực hiện đăng nhập
			loginPage.click_SignIn();
			loginPage.enterEmail(email);
			loginPage.enterPassword(password);
			loginPage.clickLogIn_SignIn();
			loginPage.click_SignOut();		
			
		//Thực hiện đăng xuất tài khoản thành công (hiển thị biểu tượng "Signup/Login" ở trang đăng nhập)
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(XPicon_signin)));
		
		Thread.sleep(2000);
	}
		
	
	@DataProvider(name = "Excel") 
	public static Object[][] datatestExcel() throws InvalidFormatException, IOException {
			String excelPath = "./data/assignment2_data_test.xlsx";
			File fileExcel = new File(excelPath);
			FileInputStream fileInputStream = null;
			Object[][] data = null;
			try {
				fileInputStream = new FileInputStream(fileExcel);
				XSSFWorkbook workbook = new XSSFWorkbook(fileExcel);
				XSSFSheet login = workbook.getSheet("Login");
				int numberOfRows = login.getPhysicalNumberOfRows();
				
				data = new Object[numberOfRows][2];
				
				for(int i = 0 ; i < numberOfRows; i++) {
					XSSFRow row = login.getRow(i);
					XSSFCell username = row.getCell(0);
					XSSFCell password = row.getCell(1);
					data[i][0] = username.getStringCellValue();
					data[i][1] = password.getStringCellValue();
				}
				workbook.close();
				return data;	
			}
			catch (Exception e) {
				System.out.println("Xảy ra lỗi khi lấy dữ liệu từ excel");
				e.printStackTrace();
			}
			finally {
				if(fileInputStream != null) {
					try {
						fileInputStream.close();
					}
					catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			
			return data;
				
	}
}
